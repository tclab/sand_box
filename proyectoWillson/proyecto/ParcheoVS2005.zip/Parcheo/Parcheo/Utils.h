#include <math.h>

class Utils
{

public:
	Utils(void);

	double porcentaje_dano(double, double, double);
	double diametroHueco(double);
};
