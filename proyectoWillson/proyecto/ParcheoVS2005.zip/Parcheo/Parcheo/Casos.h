
class Casos
{
public:
	Casos(void);

	void pielCocodrilo(double);
	void hueco(double, double);
	void grietaBorde(double);

};
