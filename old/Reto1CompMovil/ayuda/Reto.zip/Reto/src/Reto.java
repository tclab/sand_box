/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.util.Vector;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.RecordEnumeration;
import javax.microedition.rms.RecordStore;

public class Reto extends MIDlet implements CommandListener {

    private Display display;         // El display
    private CanvasDibujo canvas;      // El canvas
    private List dibujos;             // Lista de dibujos
    private Command salir, nuevo, ver;     // Comandos

    /*
     * Constuctor
     */
    public Reto() {
        display = Display.getDisplay(this);
        canvas = new CanvasDibujo(this);
        ver = new Command("Ver", Command.OK, 1);
        salir = new Command("Salir", Command.EXIT, 1);
        nuevo = new Command("Nuevo", Command.SCREEN, 1);

        dibujos = new List("Dibujos guardados", List.IMPLICIT);
        dibujos.addCommand(salir);
        dibujos.addCommand(nuevo);
        dibujos.addCommand(ver);
        dibujos.setCommandListener(this);
    }

    protected void startApp() {
        display.setCurrent(dibujos);
    }

    protected void pauseApp() {
    }

    protected void destroyApp(boolean unconditional) {
    }

//  public void exitMIDlet(){
//    destroyApp(true);
//    notifyDestroyed();
//  }
    public void commandAction(Command c, Displayable d) {
        if (c == nuevo) {
            canvas.setClearDisplay(true);
            display.setCurrent(canvas);

        } else if (c == ver) {
            canvas.leerResultados();
        } else if (c == salir) {
            destroyApp(false);
            notifyDestroyed();
        }
    }

    public void mostrarLista() {
        display.setCurrent(dibujos);
    }
    /*
     * Getters
     */

    public Display getDisplay() {
        return display;
    }

    public CanvasDibujo getCanvas() {
        return canvas;
    }

    public List getDibujos() {
        //TODO: Traer los dibujos guardados
        return dibujos;
    }
}

/**
 * Clase CanvasDibujo; maneja el evento pointer
 */
class CanvasDibujo extends Canvas implements CommandListener {

    private Command atras, atrasCanvas, limpiar, color, guardar;
    private Display pantalla;
    private List listaColores;
    private int colorPuntero;
    Coordenada nombre = new Coordenada("", null, 0);
    // Posicion inicial
    private int iniciox = 0;
    private int inicioy = 0;
    // Posici�n actual
    private int actualx = 0;
    private int actualy = 0;
    int cont = 0;
    int contar = 0;
    private Reto midlet;
    private boolean clearDisplay = true;
    private Displayable pantallaActual;
    public static RecordStore rstore;
    private Vector personas;
    Vector coord;
    int x = 255;
    int y = 255;
    int z = 255;
    boolean f = false;
    /*
     * Constructor
     */

    public CanvasDibujo(Reto midlet) {
        this.midlet = midlet;
        coord = new Vector();
        pantalla = midlet.getDisplay();

        // Inicia los comandos
        atras = new Command("Cancelar", Command.BACK, 1);
        limpiar = new Command("Limpiar", Command.SCREEN, 1);

        color = new Command("Color", Command.SCREEN, 2);
        atrasCanvas = new Command("Cancelar", Command.BACK, 1);
        guardar = new Command("Guardar", Command.OK, 3);

        listaColores = new List("Lista de colores", List.IMPLICIT);
        listaColores.append("Negro", null);
        listaColores.append("Verde", null);
        listaColores.append("Rojo", null);
        listaColores.append("Morado", null);
        listaColores.append("Naranja", null);
        listaColores.append("Azul", null);
        listaColores.addCommand(atrasCanvas);
        listaColores.setCommandListener(this);

        addCommand(atras);
        addCommand(limpiar);
        addCommand(color);
        addCommand(guardar);
        setCommandListener(this);
        getID();
    }

    protected void paint(Graphics g) {

        // Limpia el fondo
        if (clearDisplay) {
            g.setColor(x, y, z);
            g.fillRect(0, 0, getWidth(), getHeight());

            clearDisplay = false;


            iniciox = actualx = inicioy = actualy = 0;
//    coord.addElement(String.valueOf(actualx));
//    coord.addElement(String.valueOf(actualy));
//    coord.addElement(String.valueOf(iniciox));
//    coord.addElement(String.valueOf(inicioy));

            return;
        }

        // Color del lapiz
        g.setColor(colorPuntero);

        // Dibuja una linea

        

        g.drawLine(iniciox, inicioy, actualx, actualy);
//        coord.addElement(String.valueOf(actualx));
//        coord.addElement(String.valueOf(actualy));
        System.out.println(" inix" + iniciox + " iniy" + inicioy);
        System.out.println("actualx" + actualx + " actualy" + actualy);

        // El nuevo punto de inicio es la posicion actual.
        iniciox = actualx;
        inicioy = actualy;





    }

    /*
     * Eventos de comandos.
     */
    public void commandAction(Command c, Displayable d) {
        if (c == atras) {
            cont = 0;
            coord.removeAllElements();
            pantalla.setCurrent(midlet.getDibujos());
        } else if (c == limpiar) {
            clearDisplay = true;
            coord.removeAllElements();
            cont = 0;
            repaint();
        } else if (c == color) {

            pantallaActual = pantalla.getCurrent();
            pantalla.setCurrent(listaColores);
        } else if (c == atrasCanvas) {
            pantalla.setCurrent(pantallaActual);
        } else if (c == guardar) {
            //TODO: Guardar dibujo
            nombre.setNombre("Dibujo" + contar);
            nombre.setColor(colorPuntero);
            nombre.setCoord(coord);
            try {
                System.out.println(coord.size());
                Datos.savePerson(nombre);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
//         cont=0;
//         coord.removeAllElements();
            fullList();
            contar++;

            pantalla.setCurrent(midlet.getDibujos());
        } else if (c == listaColores.SELECT_COMMAND) {
            switch (listaColores.getSelectedIndex()) {
                case 0:
                    colorPuntero = 0;         //Negro
                     clearDisplay = true;
                    coord.removeAllElements();
                    cont = 0;
                    repaint();
                    pantalla.setCurrent(pantallaActual);
                   
                    break;
                case 1:
                    colorPuntero = 3394611;   //Verde

                    clearDisplay = true;
                    coord.removeAllElements();
                    cont = 0;
                    repaint();
                    pantalla.setCurrent(pantallaActual);
//                    clearDisplay = true;


                    break;
                case 2:
                    colorPuntero = 15147839;  //Rojo
                     clearDisplay = true;
                    coord.removeAllElements();
                    cont = 0;
                    repaint();
                    pantalla.setCurrent(pantallaActual);
                    
                    break;
                case 3:
                    colorPuntero = 13130703;  //Morado
                     clearDisplay = true;
                    coord.removeAllElements();
                    cont = 0;
                    repaint();
                    pantalla.setCurrent(pantallaActual);
                  
                    break;
                case 4:
                    colorPuntero = 16746536;  //Naranja
                    cont = 0;
                    coord.removeAllElements();
                    pantalla.setCurrent(pantallaActual);
                    clearDisplay = true;
                    repaint();
                    break;
                case 5:
                    colorPuntero = 4986871;   //Azul
                    cont = 0;
                    coord.removeAllElements();
                    pantalla.setCurrent(pantallaActual);
                    clearDisplay = true;
                    repaint();
                    break;
            }
        }
    }

    public void getID() {
        try {
            Vector persons = new Vector();
            //RecordStore.deleteRecordStore("personas");
            rstore = RecordStore.openRecordStore("coordenadas", true);
            //RecordStore.deleteRecordStore("personas");

            Coordenada p;
            RecordEnumeration re = rstore.enumerateRecords(null, null, true);

            while (re.hasPreviousElement()) {
                byte[] b = re.previousRecord();
                ByteArrayInputStream bais = new ByteArrayInputStream(b);
                DataInputStream dis = new DataInputStream(bais);
                String nombre = dis.readUTF();
                int color = dis.readInt();
                int a = dis.readInt();
                Vector aficiones = new Vector(a);
                for (int i = 0; i < a; i++) {
                    aficiones.addElement(dis.readUTF());
                }

                bais.reset();
                dis.reset();
                p = new Coordenada(nombre, aficiones, color);
                persons.addElement(p);
                bais.close();
                dis.close();
            }

            rstore.closeRecordStore();
        } catch (Exception e) {
        }
    }

    public void fullList() {
        midlet.getDibujos().deleteAll();
        try {
            personas = Datos.readPersons();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (personas.isEmpty()) {
            Alert alerta = new Alert("No hay datos");
            pantalla.setCurrent(alerta);
        } else {
            for (int i = 0; i < personas.size(); i++) {
                Coordenada persona = (Coordenada) personas.elementAt(i);
                midlet.getDibujos().append(persona.getNombre(), null);
            }
        }
    }

    public void leerResultados() {
        try {

            String p = midlet.getDibujos().getString(midlet.getDibujos().getSelectedIndex());
            System.out.println(p);
            Vector v = Datos.readPersons();
            Coordenada persona = (Coordenada) v.elementAt(midlet.getDibujos().getSelectedIndex());
            System.out.println(persona.getNombre());
            int color = persona.getColor();
            Vector cordes = new Vector();
            for (int i = 0; i < persona.getCoord().size(); i++) {
                String aficion = persona.getCoord().elementAt(i).toString();
                cordes.addElement(aficion);
                int cord = Integer.parseInt(aficion);
//                System.out.println("coord:"+cord);


            }
            Pantalla screen = new Pantalla(midlet, cordes, color);
//            screen.repaint();
            pantalla.setCurrent(screen);
            //pantalla.repaint();
            /* textBoxResultados.insert(nom, 0);
            textBoxResultados.insert(gen, textBoxResultados.size());
            textBoxResultados.insert(afs, textBoxResultados.size());

            display.setCurrent(textBoxResultados);*/

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    /*
     * Puntero presionado
     */

    protected void pointerPressed(int x, int y) {
        iniciox = x;
        inicioy = y;
       
       
            coord.addElement(String.valueOf(iniciox));
            coord.addElement(String.valueOf(inicioy));
        
        
        cont++;
    }

    /*
     * Movimiento de puntero
     */
    protected void pointerDragged(int x, int y) {
        actualx = x;
        actualy = y;
        coord.addElement(String.valueOf(actualx));
        coord.addElement(String.valueOf(actualy));
        repaint();
    }

    public boolean getClearDisplay() {
        return clearDisplay;
    }

    public void setClearDisplay(boolean b) {
        cont = 0;
        coord.removeAllElements();
        clearDisplay = b;
    }
}
