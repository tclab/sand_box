
import java.util.Vector;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Victor
 */
class Pantalla extends Canvas implements CommandListener
{
  private Command cmExit;          // Exit midlet

  private Command cmClear;         // Clear display

  Vector Coord;
  Reto midlet;
   private int iniciox = 0;
    private int inicioy = 0;

    // Posici�n actual
    private int actualx = 0;
    private int actualy = 0;
    int cont=0;
    int color;
  /*--------------------------------------------------
  * Constructor
  *-------------------------------------------------*/
  public Pantalla(Reto midlet,Vector Coord,int color)
  {
    this.midlet = midlet;
    this.Coord=Coord;
    this.color=color;
    // Create exit command & listen for events
    cmExit = new Command("Exit", Command.EXIT, 1);

    addCommand(cmExit);

    setCommandListener(this);
  }

  /*--------------------------------------------------
  * Paint the text representing the key code
  *-------------------------------------------------*/
  protected void paint(Graphics g)
  {
    // Clear the background (to white)
//    if (clearDisplay)
//    {
//      g.setColor(255, 255, 255);
//      g.fillRect(0, 0, getWidth(), getHeight());
//
//      clearDisplay = false;
//      startx = currentx = starty = currenty = 0;
//
//      return;
//    }

      g.setColor(255, 255, 255);
      g.fillRect(0, 0, getWidth(), getHeight());
    // Draw with black pen
    iniciox = actualx = inicioy = actualy = 0;

    // Draw line
    int i=0;
      System.out.println(Coord.size());
    while(i<Coord.size()){

        g.setColor(color);

       if(i<4){
        iniciox=Integer.parseInt(Coord.elementAt(i).toString());
        i++;

        inicioy=Integer.parseInt(Coord.elementAt(i).toString());
        i++;

        actualx = inicioy=Integer.parseInt(Coord.elementAt(i).toString());
        i++;

        actualy=inicioy=Integer.parseInt(Coord.elementAt(i).toString());
        i++;
         g.drawLine(iniciox, inicioy, actualx, actualy);

         iniciox=actualx;
         inicioy=actualy;
       }
       else{
          actualx=Integer.parseInt(Coord.elementAt(i).toString());
        i++;

        actualy=Integer.parseInt(Coord.elementAt(i).toString());
        i++;
       g.drawLine(iniciox, inicioy, actualx, actualy);
         iniciox=actualx;
         inicioy=actualy;
       }
        
//        iniciox = actualx;
//         inicioy = actualy;
    }

//        g.drawLine(startx, starty, currentx, currenty);
    }

//    g.drawLine(startx, starty, currentx, currenty);
//
//    // New starting point is the current position
//    startx = currentx;
//    starty = currenty;


  /*--------------------------------------------------
  * Command event handling
  *-------------------------------------------------*/
  public void commandAction(Command c, Displayable d)
  {
    if (c == cmExit){
       midlet.mostrarLista();
    }
//      midlet.exitMIDlet();

  }

  /*--------------------------------------------------
  * Pointer pressed
  *-------------------------------------------------*/

}