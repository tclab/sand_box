
import java.util.Vector;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Victor
 */
public class Coordenada {
     String nombre;
     int color;
    Vector coord;
    Coordenada(String nombre, Vector coord,int color  ){
        this.nombre=nombre;
        this.coord=coord;
        this.color=color;
    }
    public int getColor(){
        return color;
    }
    public void setColor(int color){
        this.color=color;
    }
     public String getNombre(){
         return nombre;
     }
     public void setNombre(String nombre){
         this.nombre=nombre;
     }
     public Vector getCoord() {
        return coord;
    }
     public void setCoord(Vector coord) {
        this.coord=coord;
    }
}
