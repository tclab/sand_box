Segundo Reto -- Android

Eduardo Gutarra Velez.
Victor Leon Higuita Cardona.
